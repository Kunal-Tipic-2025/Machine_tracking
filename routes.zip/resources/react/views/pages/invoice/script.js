function printInvoice(){
    window.print();
}