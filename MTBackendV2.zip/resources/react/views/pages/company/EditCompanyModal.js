import React, { useState, useEffect, useRef } from 'react';
import {
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
  CForm,
  CFormInput,
  CFormLabel,
  CButton,
  CFormSelect,
  CRow,
  CCol
} from '@coreui/react';
import { getAPICall, put, postFormData } from '../../../util/api';
import { useToast } from '../../common/toast/ToastContext';
import { useTranslation } from 'react-i18next';
import ImagePopup from './ImagePopup';

const EditCompanyModal = ({ visible, setVisible, companyData, onSuccess }) => {
  const { showToast } = useToast();
  const [validated, setValidated] = useState(false);
  const { t } = useTranslation("global");
  const [formData, setFormData] = useState({
    companyName: '',
    land_mark: '',
    phone_no: '',
    email_id: '',
    bank_name: '',
    account_no: '',
    IFSC_code: '',
    logo: '',
    sign: '',
    paymentQRCode: '',
    appMode: 'advance',
    tal: 'Pune',
    dist: 'Pune',
    pincode: '',
    initials: '',
    next_plan_id: '',
    subscribed_plan: '',
  });
  
  const [formErrors, setFormErrors] = useState({
    phone_no: '',
    email_id: '',
  });

  const [imagePreviews, setImagePreviews] = useState({
    logo: '',
    sign: '',
    paymentQRCode: '',
  });

  const [imagePopup, setImagePopup] = useState({ 
    visible: false, 
    src: '', 
    title: '',
    alt: ''
  });

  const [refData, setRefData] = useState({
    plans: []
  });

  const [nextBillingType, setNextBillingType] = useState('');
  const [currentBillingType, setCurrentBillingType] = useState('');

  const logoInputRef = useRef(null);
  const signInputRef = useRef(null);
  const paymentQRCodeInputRef = useRef(null);

  const appModes = [
    { label: 'Basic', value: 'basic' },
    { label: 'Advance', value: 'advance' },
  ];

  // Fetch plans data
  useEffect(() => {
    const fetchRefData = async () => {
      try {
        const response = await getAPICall('/api/detailsForCompany');
        setRefData(response || { plans: [] });
      } catch (error) {
        console.error('Error fetching reference data:', error);
        showToast('danger', 'Failed to load plans data');
      }
    };
    fetchRefData();
  }, []);

  // Determine billing type from plan name
  const getBillingTypeFromPlan = (planId) => {
    const plan = refData.plans.find(p => p.id == planId);
    if (!plan) return '';
    
    const name = plan.name.toLowerCase();
    if (name.includes('free trial')) return 'free_trial';
    if (name.includes('monthly')) return 'monthly';
    if (name.includes('quarterly')) return 'quarterly';
    if (name.includes('half-yearly')) return 'half-yearly';
    if (name.includes('annually') || name.includes('yearly')) return 'annually';
    return '';
  };

  // Image popup handlers
  const openImagePopup = (src, title, alt = 'Image') => {
    setImagePopup({ visible: true, src, title, alt });
  };

  const closeImagePopup = () => {
    setImagePopup({ visible: false, src: '', title: '', alt: '' });
  };

  useEffect(() => {
    if (companyData && visible) {
      setFormData({
        companyName: companyData.company_name || '',
        land_mark: companyData.land_mark || '',
        phone_no: companyData.phone_no || '',
        email_id: companyData.email_id || '',
        bank_name: companyData.bank_name || '',
        account_no: companyData.account_no || '',
        IFSC_code: companyData.IFSC_code || '',
        logo: companyData.logo || '',
        sign: companyData.sign || '',
        paymentQRCode: companyData.paymentQRCode || '',
        appMode: companyData.appMode || 'advance',
        tal: companyData.Tal,
        dist: companyData.Dist,
        pincode: companyData.pincode || '',
        initials: companyData.initials || '',
        next_plan_id: companyData.next_plan_id || '',
        subscribed_plan: companyData.subscribed_plan || '',
      });
      
      setImagePreviews({
        logo: companyData.logo ? `/img/${companyData.logo}` : '',
        sign: companyData.sign ? `/img/${companyData.sign}` : '',
        paymentQRCode: companyData.paymentQRCode ? `/img/${companyData.paymentQRCode}` : '',
      });

      // Determine current billing type
      if (companyData.subscribed_plan) {
        const billingType = getBillingTypeFromPlan(companyData.subscribed_plan);
        setCurrentBillingType(billingType);
      }

      // Determine next billing type if next_plan_id exists
      if (companyData.next_plan_id) {
        const nextType = getBillingTypeFromPlan(companyData.next_plan_id);
        setNextBillingType(nextType);
      }
      
      setValidated(false);
      setFormErrors({
        phone_no: '',
        email_id: '',
      });
    }
  }, [companyData, visible, refData.plans]);

  const handleChange = (event) => {
    const { name, value, files } = event.target;
    if (files && files.length > 0) {
      const file = files[0];
      setFormData({ ...formData, [name]: file });
      
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          setImagePreviews(prev => ({
            ...prev,
            [name]: e.target.result
          }));
        };
        reader.readAsDataURL(file);
      }
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleRemoveImage = (imageType) => {
    setFormData({ ...formData, [imageType]: '' });
    setImagePreviews(prev => ({ ...prev, [imageType]: '' }));
    
    if (imageType === 'logo' && logoInputRef.current) {
      logoInputRef.current.value = '';
    } else if (imageType === 'sign' && signInputRef.current) {
      signInputRef.current.value = '';
    } else if (imageType === 'paymentQRCode' && paymentQRCodeInputRef.current) {
      paymentQRCodeInputRef.current.value = '';
    }
  };

  const handleSubmit = async (event) => {
    const form = event.currentTarget;
    event.preventDefault();
    event.stopPropagation();
    setValidated(true);
    
    if (form.checkValidity() !== true) {
      showToast('danger', 'Kindly provide data of all required fields');
      return;
    }

    try {
      let updatedData = { ...formData };

      if (formData.logo instanceof File) {
        const logoData = new FormData();
        logoData.append('file', formData.logo);
        logoData.append('dest', 'invoice');
        const responseLogo = await postFormData('/api/fileUpload', logoData);
        updatedData.logo = responseLogo.fileName;
      }

      if (formData.sign instanceof File) {
        const signData = new FormData();
        signData.append('file', formData.sign);
        signData.append('dest', 'invoice');
        const responseSign = await postFormData('/api/fileUpload', signData);
        updatedData.sign = responseSign.fileName;
      }

      if (formData.paymentQRCode instanceof File) {
        const paymentQRCodeData = new FormData();
        paymentQRCodeData.append('file', formData.paymentQRCode);
        paymentQRCodeData.append('dest', 'invoice');
        const responseQRCode = await postFormData('/api/fileUpload', paymentQRCodeData);
        updatedData.paymentQRCode = responseQRCode.fileName;
      }

      const updatePayload = {
        company_name: updatedData.companyName,
        land_mark: updatedData.land_mark,
        tal: updatedData.tal,
        dist: updatedData.dist,
        pincode: updatedData.pincode,
        phone_no: updatedData.phone_no,
        email_id: updatedData.email_id,
        bank_name: updatedData.bank_name || '',
        account_no: updatedData.account_no || '',
        IFSC_code: updatedData.IFSC_code || '',
        logo: updatedData.logo || '',
        sign: updatedData.sign || '',
        paymentQRCode: updatedData.paymentQRCode || '',
        appMode: updatedData.appMode || 'advance',
        initials: updatedData.initials || 'INV',
        next_plan_id: updatedData.next_plan_id || null,
      };

      console.log('Update payload:', updatePayload);

      const response = await put(`/api/companies/${companyData.company_id}`, updatePayload);

      showToast('success', 'Company details updated successfully.');
      setVisible(false);
      if (onSuccess) onSuccess();
    } catch (error) {
      console.error('Error updating company:', error);
      showToast('danger', 'Error occurred: ' + (error.response?.data?.message || error.message));
    }
  };

  const ImagePreview = ({ src, alt, onRemove, label }) => (
    <div className="image-preview-container mt-2">
      {src ? (
        <div className="d-flex align-items-center gap-2 p-2 bg-light rounded">
          <button
            type="button"
            className="btn btn-link p-0 text-primary"
            style={{ 
              fontSize: '14px',
              textDecoration: 'none'
            }}
            onClick={() => openImagePopup(src, `${label} Preview`, `${label} image`)}
            title={`View ${label}`}
          >
            <i className="fas fa-eye me-1"></i>
            View {label}
          </button>
          <button
            type="button"
            className="btn btn-danger btn-sm"
            style={{ 
              fontSize: '12px',
              padding: '4px 8px'
            }}
            onClick={onRemove}
            title={`Remove ${label}`}
          >
            <i className="fas fa-trash me-1"></i>
            Remove
          </button>
        </div>
      ) : (
        <div className="text-muted small fst-italic mt-1">
          <i className="fas fa-image me-1"></i>
          No {label.toLowerCase()} selected
        </div>
      )}
    </div>
  );

  // Check if current plan is free trial
  const isCurrentPlanFreeTrial = () => {
    if (!formData.subscribed_plan) return false;
    const plan = refData.plans.find(p => p.id == formData.subscribed_plan);
    return plan?.name?.toLowerCase().includes('free trial');
  };

  return (
    <>
      <CModal
        visible={visible}
        onClose={() => setVisible(false)}
        size="xl"
        backdrop="static"
      >
        <CModalHeader>
          <CModalTitle>{t("LABELS.edit_company")}: {companyData?.company_name}</CModalTitle>
        </CModalHeader>
        <CModalBody>
          <CForm noValidate validated={validated} onSubmit={handleSubmit} encType='multipart/form-data'>
            <div className='row'>
              <div className='col-sm-4'>
                <div className='mb-3'>
                  <CFormLabel htmlFor="companyName">{t("LABELS.company_name")}</CFormLabel>
                  <CFormInput
                    type='text'
                    name='companyName'
                    id='companyName'
                    maxLength="100"
                    value={formData.companyName}
                    onChange={handleChange}
                    feedbackInvalid="Please provide valid data."
                    required
                  />
                </div>
              </div>
              <div className='col-sm-8'>
                <div className='mb-3'>
                  <CFormLabel htmlFor="land_mark">{t("LABELS.address_label")}</CFormLabel>
                  <CFormInput
                    type='text'
                    name='land_mark'
                    id='land_mark'
                    maxLength="100"
                    value={formData.land_mark}
                    onChange={handleChange}
                    feedbackInvalid="Please provide shop address."
                    required
                  />
                </div>
              </div>
            </div>

            {/* Taluka, District, Pincode Row */}
            <div className='row'>
              <div className='col-sm-4'>
                <div className='mb-3'>
                  <CFormLabel htmlFor="tal">{t("LABELS.taluka") || "Taluka"}</CFormLabel>
                  <CFormInput
                    type='text'
                    name='tal'
                    id='tal'
                    maxLength="50"
                    value={formData.tal}
                    onChange={handleChange}
                    feedbackInvalid="Please provide taluka."
                    required
                  />
                </div>
              </div>
              <div className='col-sm-4'>
                <div className='mb-3'>
                  <CFormLabel htmlFor="dist">{t("LABELS.district") || "District"}</CFormLabel>
                  <CFormInput
                    type='text'
                    name='dist'
                    id='dist'
                    maxLength="50"
                    value={formData.dist}
                    onChange={handleChange}
                    feedbackInvalid="Please provide district."
                    required
                  />
                </div>
              </div>
              <div className='col-sm-4'>
                <div className='mb-3'>
                  <CFormLabel htmlFor="pincode">{t("LABELS.pincode") || "Pincode"}</CFormLabel>
                  <CFormInput
                    type='text'
                    name='pincode'
                    id='pincode'
                    maxLength="6"
                    minLength="6"
                    pattern="[0-9]{6}"
                    value={formData.pincode}
                    onChange={handleChange}
                    feedbackInvalid="Please provide valid 6-digit pincode."
                    required
                  />
                </div>
              </div>
            </div>
            
            {/* Phone and Email Row */}
            <div className='row'>
              <div className='col-sm-4'>
                <div className='mb-3'>
                  <CFormLabel htmlFor="phone_no">{t("LABELS.mobile_number")}</CFormLabel>
                  <CFormInput
                    type='text'
                    name='phone_no'
                    id='phone_no'
                    value={formData.phone_no}
                    onChange={handleChange}
                    invalid={!!formErrors.phone_no}
                    feedbackInvalid={formErrors.phone_no !== '' ? formErrors.phone_no : "Please provide valid 10 digit mobile."}
                    pattern="\d{10}"
                    required
                    minLength={10}
                    maxLength={10}
                  />
                </div>
              </div>
              <div className='col-sm-4'>
                <div className='mb-3'>
                  <CFormLabel htmlFor="email_id">{t("LABELS.email")}</CFormLabel>
                  <CFormInput
                    type='email'
                    name='email_id'
                    id='email_id'
                    invalid={!!formErrors.email_id}
                    value={formData.email_id}
                    onChange={handleChange}
                    feedbackInvalid={formErrors.email_id !== '' ? formErrors.email_id : "Please provide email address."}
                    required
                  />
                </div>
              </div>
              <div className='col-sm-4'>
                <div className='mb-3'>
                  <CFormLabel htmlFor="initials">{t("LABELS.initials") || "Initials"}</CFormLabel>
                  <CFormInput
                    type='text'
                    name='initials'
                    id='initials'
                    maxLength="10"
                    value={formData.initials}
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            {/* Bank Details Row */}
            <div className='row'>
              <div className='col-sm-4'>
                <div className='mb-3'>
                  <CFormLabel htmlFor="bank_name">{t("LABELS.bank_name")}</CFormLabel>
                  <CFormInput
                    type='text'
                    name='bank_name'
                    id='bank_name'
                    value={formData.bank_name}
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className='col-sm-4'>
                <div className='mb-3'>
                  <CFormLabel htmlFor="account_no">{t("LABELS.account_number")}</CFormLabel>
                  <CFormInput
                    type='number'
                    name='account_no'
                    id='account_no'
                    value={formData.account_no}
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className='col-sm-4'>
                <div className='mb-3'>
                  <CFormLabel htmlFor="IFSC_code">{t("LABELS.IFSC")}</CFormLabel>
                  <CFormInput
                    type='text'
                    name='IFSC_code'
                    id='IFSC_code'
                    value={formData.IFSC_code}
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            {/* Next Renewal Plan Section - Only show if current plan is Free Trial */}
            {isCurrentPlanFreeTrial() && (
              <div className='row'>
                <div className='col-sm-12'>
                  <h5 className="mt-3 mb-3">Next Renewal Plan</h5>
                </div>
                <div className="col-sm-6">
                  <div className="mb-3">
                    <CFormLabel htmlFor="next_billing_type">
                      {t("LABELS.next_renewal_type") || "Next Renewal Type"}
                    </CFormLabel>
                    <CFormSelect
                      id="next_billing_type"
                      name="next_billing_type"
                      value={nextBillingType}
                      onChange={(e) => {
                        setNextBillingType(e.target.value);
                        setFormData((prev) => ({ ...prev, next_plan_id: '' }));
                      }}
                    >
                      <option value="">{t("LABELS.select_next_type") || "-- Select Type --"}</option>
                      <option value="monthly">{t("LABELS.monthly") || "Monthly"}</option>
                      <option value="quarterly">{t("LABELS.quarterly") || "Quarterly"}</option>
                      <option value="half-yearly">{t("LABELS.half_yearly") || "Half-Yearly"}</option>
                      <option value="annually">{t("LABELS.annually") || "Annually"}</option>
                    </CFormSelect>
                  </div>
                </div>

                <div className="col-sm-6">
                  <div className="mb-3">
                    <CFormLabel htmlFor="next_plan_id">
                      {t("LABELS.next_renewal_plan") || "Next Renewal Plan"}
                    </CFormLabel>
                    <CFormSelect
                      id="next_plan_id"
                      name="next_plan_id"
                      value={formData.next_plan_id || ''}
                      onChange={handleChange}
                      disabled={!nextBillingType}
                    >
                      <option value="">-- Select Plan --</option>
                      {refData.plans
                        .filter((plan) => {
                          const name = plan.name?.toLowerCase() || '';
                          return (
                            nextBillingType &&
                            name.includes(nextBillingType.toLowerCase()) &&
                            !name.includes("free trial")
                          );
                        })
                        .map((plan) => (
                          <option key={plan.id} value={plan.id}>
                            {plan.name}
                          </option>
                        ))}
                    </CFormSelect>
                  </div>
                </div>
              </div>
            )}
            
            {/* Image Upload Section with Enhanced Previews */}
            <div className='row'>
              <div className='col-sm-4'>
                <div className='mb-3'>
                  <CFormLabel htmlFor="logo">{t("LABELS.logo")}</CFormLabel>
                  <CFormInput
                    type='file'
                    name='logo'
                    id='logo'
                    accept='image/png, image/jpeg'
                    onChange={handleChange}
                    ref={logoInputRef}
                  />
                  <ImagePreview 
                    src={imagePreviews.logo} 
                    alt="Logo Preview" 
                    onRemove={() => handleRemoveImage('logo')}
                    label="Logo"
                  />
                </div>
              </div>
              <div className='col-sm-4'>
                <div className='mb-3'>
                  <CFormLabel htmlFor="sign">{t("LABELS.sign")}</CFormLabel>
                  <CFormInput
                    type='file'
                    name='sign'
                    id='sign'
                    accept='image/png, image/jpeg'
                    onChange={handleChange}
                    ref={signInputRef}
                  />
                  <ImagePreview 
                    src={imagePreviews.sign} 
                    alt="Signature Preview" 
                    onRemove={() => handleRemoveImage('sign')}
                    label="Signature"
                  />
                </div>
              </div>
              <div className='col-sm-4'>
                <div className='mb-3'>
                  <CFormLabel htmlFor="paymentQRCode">{t("LABELS.qr_img")}</CFormLabel>
                  <CFormInput
                    type='file'
                    name='paymentQRCode'
                    id='paymentQRCode'
                    accept='image/png, image/jpeg'
                    onChange={handleChange}
                    ref={paymentQRCodeInputRef}
                  />
                  <ImagePreview 
                    src={imagePreviews.paymentQRCode} 
                    alt="QR Code Preview" 
                    onRemove={() => handleRemoveImage('paymentQRCode')}
                    label="QR Code"
                  />
                </div>
              </div>
            </div>
            
            <div className="d-flex gap-2">
              <CButton type="submit" color="primary">
                <i className="fas fa-save me-1"></i>
                {t("LABELS.update")}
              </CButton>
              <CButton 
                type="button" 
                color="secondary" 
                variant="outline"
                onClick={() => setVisible(false)}
              >
                <i className="fas fa-times me-1"></i>
                {t("LABELS.cancel")}
              </CButton>
            </div>
          </CForm>
        </CModalBody>
      </CModal>
      
      {/* Image Popup Modal */}
      <ImagePopup 
        visible={imagePopup.visible}
        onClose={closeImagePopup}
        src={imagePopup.src}
        title={imagePopup.title}
        alt={imagePopup.alt}
      />
    </>
  );
};

export default EditCompanyModal;